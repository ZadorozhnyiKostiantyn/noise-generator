#pragma once
#include <WString.h>

void setupDisplay();
void drawMessage(String message);