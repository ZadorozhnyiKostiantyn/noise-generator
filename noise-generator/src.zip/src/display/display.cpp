#include <SSD1306Wire.h>

SSD1306Wire display(0x3c, SDA, SCL);

void setupDisplay() {
  display.init(); // Initialize the OLED display
  display.clear(); // Clear the display buffer
  display.flipScreenVertically();
  display.setFont(ArialMT_Plain_24);
  display.setTextAlignment(TEXT_ALIGN_LEFT);
  // display.setPixelColor(0, 5, BLACK); // Set a pixel at (0, 0)
  display.setColor(WHITE);
  display.drawString(0, 0, "Hello!");
  display.display(); // Actually display all of the above
}

void drawMessage(String message) {
  display.clear();
  display.drawString(0, 0, message);
  display.display();
}