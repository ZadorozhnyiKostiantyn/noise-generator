#pragma once

#include <Arduino.h>

void setupAudio();
void startPlayback(String filename);
void stopPlayback();
void startRecording(const char *filename);
void stopRecording();

extern bool isPlaying; 
extern bool isRecording; 
extern bool isUltrasonic; 


