#include "audio.h"
#include "config/config.h"
#include "wav/wav_utils.h"
#include <SD.h>
#include <driver/i2s.h>
#include <Arduino.h>
#include <stdio.h>
#include <freertos/FreeRTOS.h>

static TaskHandle_t playbackTaskHandle = nullptr;
static TaskHandle_t recordingTaskHandle = nullptr;
bool isPlaying = false;
bool isRecording = false;
bool isUltrasonic = false;
static const i2s_port_t i2s_num = I2S_NUM_0; // i2s port number
unsigned const char *TheData;
uint32_t DataIdx = 0;
struct WavHeader_Struct WavHeader;
static String currentFilenameStr;

// ─────────────────────────────────────────────────────────────────────────────
// Ініціалізація I2S
void setupAudio()
{
    ledcSetup(ULTRASOUND_CHANNEL, ULTRASOUND_FREQUENCY, ULTRASOUND_RESOLUTION);
    ledcAttachPin(ULTRASOUND_PIN, ULTRASOUND_CHANNEL);
    i2s_driver_install(i2s_num, &i2s_speaker_config, 0, NULL);
    i2s_set_pin(i2s_num, &i2s_speaker_pins);
}

void startUltrasound()
{
    // Встановлення заповнення 50% для ШІМ
    ledcWrite(0, 128); // 128 із 255 (50%)
}

void stopUltrasound()
{
    // Зупинка ШІМ
    ledcWrite(0, 0);
}

// ─────────────────────────────────────────────────────────────────────────────
// Функція для запису
void recordTask(void *param)
{
    const char *filename = (const char *)param;
    int16_t *samples = (int16_t *)malloc(sizeof(int16_t) * 1024);
    FILE *fp = fopen(filename, "wb");

    fclose(fp);
    free(samples);
    isRecording = false;
    Serial.println("Recording finished.");
    vTaskDelete(nullptr);
}

void startRecording(const char *filename)
{
    if (isRecording)
    {
        Serial.println("Recording is already in progress.");
        return;
    }
    isRecording = true;
    xTaskCreatePinnedToCore(recordTask, "RecordTask", 4096, (void *)filename, 1, &recordingTaskHandle, 1);
}

void stopRecording()
{
    if (isRecording)
    {
        gpio_set_level(GPIO_BUTTON, 0); // Симуляція відпускання кнопки
        isRecording = false;
    }
}

void playbackTask(void *param)
{
    startUltrasound();
    return;
    const char *filename = (const char *)param;

    while (true)
    {
        if (!isPlaying)
        {
            vTaskSuspend(nullptr); // Суспендить сама себе
        }

        File file = SD.open(filename, FILE_READ);
        if (!file)
        {
            Serial.println("Failed to open file for playback.");
            continue;
        }

        // Зчитування заголовка WAV
        file.read((uint8_t *)&WavHeader, sizeof(WavHeader_Struct));
        if (!ValidWavData(&WavHeader))
        {
            Serial.println("Invalid WAV file.");
            file.close();
            continue;
        }

        DumpWAVHeader(&WavHeader);
        i2s_set_sample_rates(i2s_num, WavHeader.SampleRate);

        size_t bytesRead;
        size_t bytesWritten;
        const int bufferSize = 512;
        uint8_t buffer[bufferSize];

        while (file.available() && isPlaying)
        {
            bytesRead = file.read(buffer, bufferSize);

            if (WavHeader.NumChannels == 1)
            {
                uint8_t stereoBuffer[bufferSize * 2];
                for (int i = 0, j = 0; i < bytesRead; i += 2, j += 4)
                {
                    stereoBuffer[j] = buffer[i];
                    stereoBuffer[j + 1] = buffer[i + 1];
                    stereoBuffer[j + 2] = buffer[i];
                    stereoBuffer[j + 3] = buffer[i + 1];
                }
                i2s_write(i2s_num, stereoBuffer, bytesRead * 2, &bytesWritten, portMAX_DELAY);
            }
            else
            {
                i2s_write(i2s_num, buffer, bytesRead, &bytesWritten, portMAX_DELAY);
            }
        }

        file.close();
        Serial.println("Playback finished or stopped.");
    }
}

void startPlayback(String filename)
{
    currentFilenameStr = filename;

    if (playbackTaskHandle == nullptr)
    {
        const char *filenameC = currentFilenameStr.c_str();
        isPlaying = true;
        xTaskCreatePinnedToCore(playbackTask, "PlaybackTask", 4096, (void *)filenameC, 1, &playbackTaskHandle, 0);
    }
    else
    {
        isPlaying = true;
        vTaskResume(playbackTaskHandle);
    }
}

void stopPlayback()
{
    Serial.println("Stopping playback...");
    isPlaying = false;
    stopUltrasound();

    if (playbackTaskHandle != nullptr)
    {
        vTaskSuspend(playbackTaskHandle);
        // ❌ Не видаляємо таску
        // ✅ Вона залишиться в пам’яті і "спатиме"
    }
}