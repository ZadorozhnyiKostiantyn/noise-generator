#pragma once

#include <vector>
#include <Arduino.h>

void setupSDCard();
std::vector<String> getListFiles();
